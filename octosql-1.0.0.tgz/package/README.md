# OctoSQL Database Engine

> **OctoSQL** is an independent, high-performance, encrypted relational and document database system built from scratch in Node.js. It features a custom storage engine (`.osql`), Write-Ahead Logging (`.owal`), dual-syntax execution (Standard ANSI SQL & OctoSQLX dialect), an integrated Redis caching layer with fallback, and **OctoAdminer**—a classic, lightweight database workbench.

---

## 🌟 Key Features

- **Custom Binary/Structured Storage (`.osql`):** Tables are stored in structured binary files with magic headers (`OCTOSQL_V1`), schemas, and **AES-256-GCM** authenticated encrypted blocks at rest.
- **ACID Durability with Write-Ahead Logging (`.owal`):** Atomic disk synchronization with automatic crash recovery on startup.
- **Dual Query Dialect:**
  - **ANSI SQL:** `SELECT`, `INSERT INTO`, `UPDATE`, `DELETE`, `CREATE TABLE`, `DROP TABLE`, `TRUNCATE`, `SHOW TABLES`, `DESCRIBE`.
  - **OctoSQLX:** High-productivity modern dialect featuring `FETCH`, `STORE`, `MUTATE`, `PURGE`, `SPAWN TABLE`.
- **Integrated Redis Caching:** Automatically connects to Redis (`127.0.0.1:6379`) with transparent fallback to an in-memory TTL/LRU store. Query results are cached with sub-millisecond lookups and invalidated on write operations.
- **IP Whitelist Firewall:** OctoAdminer and administrative endpoints are protected against unauthorized access. Non-system IPs are blocked with `HTTP 403 Forbidden` and audited to disk.
- **Standard SQL Driver API:** Fully compliant with standard Node.js SQL libraries (`createConnection`, `createPool`, array destructuring `const [rows, fields] = await conn.query(...)`, prepared statements with `?` parameter binding, and transactions).
- **OctoAdminer Workbench:** Classic, distraction-free database administration UI with 16x16 legacy icons, tree navigation, manual row editors, and SQL console.

---

## 📐 Data Types Supported

OctoSQL natively supports all core relational and modern document data types:

| Data Type | Description | Example |
| :--- | :--- | :--- |
| `INTEGER` / `INT` | 64-bit integer numbers | `42`, `-100` |
| `FLOAT` / `DECIMAL` / `NUMBER` | Floating-point real numbers | `3.14159`, `99.95` |
| `TEXT` / `VARCHAR` / `STRING` | Variable-length UTF-8 text | `'Hello world'` |
| `BOOLEAN` / `BOOL` | Boolean values | `true`, `false` |
| `JSON` | Native structured JSON objects and arrays | `{"theme": "dark", "tags": [1, 2]}` |
| `DATETIME` / `TIMESTAMP` | ISO-8601 timestamps | `'2026-10-29T14:00:00.000Z'` |
| `UUID` | Cryptographically secure UUID v4 | `'d9f958f0-128a-4c8d-b0a5-8123bc89a742'` |

---

## 🚀 Quick Start

### 1. Installation
Install OctoSQL as a dependency in your project or clone the repository:

```bash
# In your project root
npm install ./path-to/octosql
# or
npm install octosql
```

### 2. Start the Database Daemon
Run the standalone database server:

```bash
# Using CLI
npx octosql start

# Or directly with Node
node daemon.js
```

The daemon will start listening on port `8421`:
- **Database Endpoint:** `http://127.0.0.1:8421/api/query`
- **OctoAdminer Workbench:** `http://127.0.0.1:8421/admin`

### 3. Check Server Status
```bash
npx octosql status
```

---

## ⌨️ Query Syntax Comparison

OctoSQL supports standard ANSI SQL and the streamlined OctoSQLX dialect side-by-side:

| Action | Standard ANSI SQL | OctoSQLX Dialect |
| :--- | :--- | :--- |
| **Select** | `SELECT * FROM pages WHERE status = 'published'` | `FETCH * FROM pages FILTER status = 'published'` |
| **Ordering & Limits** | `... ORDER BY id DESC LIMIT 5 OFFSET 10` | `... SORT id DESC RANGE 5 SKIP 10` |
| **Update** | `UPDATE pages SET status = 'draft' WHERE id = '1'` | `MUTATE pages SET status = 'draft' FILTER id = '1'` |
| **Insert / Store** | `INSERT INTO locales (code) VALUES ('az')` | `STORE IN locales OBJECT {"code": "az", "isDefault": true}` |
| **Delete / Purge** | `DELETE FROM pages WHERE id = 'page-old'` | `PURGE FROM pages FILTER id = 'page-old'` |
| **Create Table** | `CREATE TABLE users (id UUID PRIMARY KEY, name TEXT)` | `SPAWN TABLE users WITH (id UUID PRIMARY KEY, name TEXT)` |

---

## 🛡️ Security & Encryption Architecture

1. **At-Rest Encryption:**
   Every row stored in a `.osql` file is authenticated and encrypted using **AES-256-GCM**. The payload format includes a unique 96-bit initialization vector (IV) and 128-bit authentication tag to prevent tampering.
2. **IP Whitelist Firewall:**
   Only verified system IPs (`127.0.0.1`, `::1`, `localhost` or configured CIDRs) can access administrative APIs. Unrecognized requests are rejected with `HTTP 403` and logged to `data/security_audit.log`.
3. **Prepared Statements & Sanitization:**
   Client parameter binding (`?`, `$1`, `:name`) protects against SQL injection, while built-in XSS sanitizers prevent stored scripts.

---

## 📦 Directory Structure

```text
octosql/
├── bin/
│   └── octosql.js             # CLI executable (start, status, version)
├── data/
│   ├── *.osql                 # AES-256-GCM encrypted database tables
│   ├── *.owal                 # Write-Ahead Logs
│   └── security_audit.log     # Firewall security audit trail
├── lib/
│   ├── index.js               # Library entry point
│   ├── index.d.ts             # TypeScript definitions
│   ├── client.js              # Connection & Pool driver
│   ├── engine.js              # ANSI SQL & OctoSQLX query engine
│   ├── storage.js             # Custom .osql disk storage engine
│   ├── cache.js               # Redis & in-memory cache layer
│   ├── crypto.js              # AES-256-GCM & UUID utilities
│   └── firewall.js            # IP Whitelist middleware
├── views/
│   └── studio.ejs             # OctoAdminer legacy workbench UI
├── daemon.js                  # Standalone server daemon
├── test.js                    # Core engine unit tests
├── test_connection.js         # SQL driver integration tests
├── Dockerfile                 # Container image specification
├── docker-compose.yml         # Compose stack with Redis
└── CONNECTING.md              # Node.js Integration & Driver Guide
```

---

## 📄 License
MIT &copy; Ali Yabuz. All rights reserved.
